
swmm.toolkit.shared_enum module
===============================

.. automodule:: swmm.toolkit.shared_enum
    :members:
    :no-undoc-members:
    :show-inheritance: