


.. _api_documentation:

API documentation
===================

.. automodule:: swmm
    :members:
    :no-undoc-members:
    :show-inheritance:

Subpackages
-----------

.. toctree::
    :maxdepth: 1

    swmm.toolkit
