

swmm.toolkit.solver module
==========================


.. automodule:: swmm.toolkit.solver
    :members:
    :no-undoc-members:
    :show-inheritance:


.. autoclass:: swmm.toolkit.solver.NodeStats
.. autoclass:: swmm.toolkit.solver.StorageStats
.. autoclass:: swmm.toolkit.solver.OutfallStats
.. autoclass:: swmm.toolkit.solver.LinkStats
.. autoclass:: swmm.toolkit.solver.PumpStats
.. autoclass:: swmm.toolkit.solver.SubcatchStats
.. autoclass:: swmm.toolkit.solver.RoutingTotals
.. autoclass:: swmm.toolkit.solver.RunoffTotals
