.. swmm.toolkit documentation master file, created by
   sphinx-quickstart on Mon Jun 15 13:57:22 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.


Welcome to swmm.toolkit's documentation!
========================================

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   API documentation <apidoc/swmm>


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
