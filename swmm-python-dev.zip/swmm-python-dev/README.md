# swmm-python


## Contents
nrtest-swmm  - Plugin for performing numerical regression testing on swmm-solver.


swmm-toolkit - SWIG based wrappers for the swmm-solver and swmm-output libraries.

![Build Wheels](https://github.com/SWMM-Project/swmm-python/workflows/Build%20Wheels/badge.svg)
